namespace AssetsExporter.YAML
{
	internal enum MetaType
	{
		YAML,
		TAG,
	}
}
