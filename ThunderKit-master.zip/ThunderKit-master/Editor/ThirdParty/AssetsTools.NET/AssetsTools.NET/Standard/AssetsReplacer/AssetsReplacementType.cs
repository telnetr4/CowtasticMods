﻿namespace AssetsTools.NET
{
    public enum AssetsReplacementType
    {
        AddOrModify,
        Remove,
        //deprecated
        AssetsReplacement_AddOrModify = 0,
        AssetsReplacement_Remove = 1
    }
}
