﻿namespace AssetsTools.NET
{
    public class TypeField_07
    {
        public string type;
        public string name;
        public uint size;
        public uint index;
        public uint arrayFlag;
        public uint flags1;
        public uint flags2;
        public uint childrenCount;
        public TypeField_07[] children;
    }
}
