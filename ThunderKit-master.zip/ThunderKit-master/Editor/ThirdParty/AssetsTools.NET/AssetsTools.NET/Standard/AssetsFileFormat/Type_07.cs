﻿namespace AssetsTools.NET
{
    public class Type_07
    {
        public int classId;
        public TypeField_07 @base;
    }
}
