﻿namespace AssetsTools.NET
{
    public class AssetsBundleOffsetPair
    {
        public uint compressed;
        public uint uncompressed;
    }
}
