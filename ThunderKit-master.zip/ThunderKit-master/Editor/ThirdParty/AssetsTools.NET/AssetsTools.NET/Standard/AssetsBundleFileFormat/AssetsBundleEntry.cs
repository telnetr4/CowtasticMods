﻿namespace AssetsTools.NET
{
    public class AssetsBundleEntry
    {
        public uint offset;
        public uint length;
        public byte name;
    }
}
