﻿namespace AssetsTools.NET
{
    public class AssetsList
    {
        public uint pos;
        public uint count;
        public AssetsBundleEntry[] entries;
        public uint allocatedCount;
    }
}
