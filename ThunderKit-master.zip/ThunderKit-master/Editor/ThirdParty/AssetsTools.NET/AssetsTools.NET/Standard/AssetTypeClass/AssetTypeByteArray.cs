﻿namespace AssetsTools.NET
{
    public struct AssetTypeByteArray
    {
        public uint size;
        public byte[] data;
    }
}
