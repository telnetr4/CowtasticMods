﻿namespace AssetsTools.NET
{
    public struct AssetTypeArray
    {
        public int size;
    }
}
