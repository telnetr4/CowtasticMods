﻿namespace AssetsTools.NET
{
    public enum BundleReplacementType
    {
        AddOrModify,
        Rename,
        Remove
    }
}
