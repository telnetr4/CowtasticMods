# AssetRipper.VersionUtilities

[![](https://img.shields.io/nuget/v/AssetRipper.VersionUtilities)](https://www.nuget.org/packages/AssetRipper.VersionUtilities)

Managed library for handling Unity versions

# Legal Disclaimers

Forked code from [uTinyRipper](https://github.com/mafaca/UtinyRipper) is licensed under the [MIT license](Licenses/uTinyRipper.md).

This software is not sponsored by or affiliated with Unity Technologies or its affiliates. "Unity" is a registered trademark of Unity Technologies or its affiliates in the U.S. and elsewhere.