﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("VersionUtilities.Tests")]