﻿using System;

namespace ThunderKit.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false, Inherited = false)]
    public class PathReferenceResolverAttribute : Attribute
    {
    }
}