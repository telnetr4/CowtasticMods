﻿using UnityEditorInternal;

namespace ThunderKit.Core.Manifests.Datums
{
    public class AssemblyDefinitions : ManifestDatum
    {
        public AssemblyDefinitionAsset[] definitions;
    }
}