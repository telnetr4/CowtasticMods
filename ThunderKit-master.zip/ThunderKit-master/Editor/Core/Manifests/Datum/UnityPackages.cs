﻿using ThunderKit.Core.Data;

namespace ThunderKit.Core.Manifests.Datums
{
    public class UnityPackages : ManifestDatum
    {
        public UnityPackage[] unityPackages;
    }
}