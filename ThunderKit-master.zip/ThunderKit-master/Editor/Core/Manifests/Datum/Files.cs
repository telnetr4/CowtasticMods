using UnityEngine;

namespace ThunderKit.Core.Manifests.Datum
{
    public class Files : ManifestDatum
    {
        public Object[] files;
    }
}
