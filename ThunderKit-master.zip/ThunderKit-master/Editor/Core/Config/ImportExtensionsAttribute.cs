﻿using System;

namespace ThunderKit.Core.Config
{
    [AttributeUsage(AttributeTargets.Assembly)]
    public class ImportExtensionsAttribute : Attribute { }
}