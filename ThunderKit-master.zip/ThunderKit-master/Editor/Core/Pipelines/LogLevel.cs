﻿namespace ThunderKit.Core.Pipelines
{
    public enum LogLevel { Information, Warning, Error }
}