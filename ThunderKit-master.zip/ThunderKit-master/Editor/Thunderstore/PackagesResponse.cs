﻿using System;

namespace ThunderKit.Integrations.Thunderstore
{
    [Serializable]
    public class PackagesResponse 
    {
        public PackageListing[] results;
    }
}