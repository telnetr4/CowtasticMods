﻿using ThunderKit.Core.Manifests;

namespace ThunderKit.Integrations.Thunderstore
{
    public class ThunderstoreData : ManifestDatum
    {
        public string url;
    }
}