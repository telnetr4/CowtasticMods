Warning: No game configured. {.warning }

Browse to the Game and then import using the section below to setup your ThunderKit Project before continuing{.error }