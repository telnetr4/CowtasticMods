---
{
	"title" : "Change Log",
	"contentUrl" : "Packages/com.passivepicasso.thunderkit/CHANGELOG.md",
	"headerClasses" : [ "bm4", "page-header-container" ],
	"titleClasses" : [ "page-header" ],
	"iconClasses" : [ "header-icon", "TK_Documentation_2X_Icon" ]
}

---