---
{ 
	"title" : "ThunderKitSetting",
	"headerClasses" : [ "bm4", "page-header-container" ],
	"titleClasses" : [ "page-header" ],
	"iconClasses" : [ "header-icon", "TK_ThunderKitSetting_2X_Icon" ]
}

---

ThunderKitSetting is another extensible portion of ThunderKit which provides the ability to host centralized settings files for projects.
These settings are intended for extensions to ThunderKit such as new PackageSources

ThunderKitSetting are all available in the [ThunderKit Settings Window](menulink://Tools/ThunderKit/Settings)