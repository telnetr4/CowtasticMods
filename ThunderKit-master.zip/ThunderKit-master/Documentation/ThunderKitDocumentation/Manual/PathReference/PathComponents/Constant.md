---
{ 
	"title" : "Constant",
	"headerClasses" : [ "bm4", "page-header-container" ],
	"titleClasses" : [ "page-header" ],
	"iconClasses" : [ "header-icon", "TK_PathReference_2X_Icon" ]
}

---

[Constant](assetlink://GUID/cebc722807299b54bb8733330087d5e3) will return the provided literal value

## Fields

* **Value**
  - Constant value to return

## Remarks

None