---
{ 
	"title" : "GameExecutable",
	"headerClasses" : [ "bm4", "page-header-container" ],
	"titleClasses" : [ "page-header" ],
	"iconClasses" : [ "header-icon", "TK_PathReference_2X_Icon" ]
}

---

[GameExecutable](assetlink://GUID/590bd9fa6d6a2ba4b966390dfd0a9085) will return the value of GameExecutable in your [ThunderKitSettings](menulink://Tools/ThunderKit/Settings)

## Remarks

Use this if you need to retrieve the games executable