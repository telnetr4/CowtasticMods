---
{ 
	"title" : "ThunderKitRoot",
	"headerClasses" : [ "bm4", "page-header-container" ],
	"titleClasses" : [ "page-header" ],
	"iconClasses" : [ "header-icon", "TK_PathReference_2X_Icon" ]
}

---

[ThunderKitRoot](assetlink://GUID/49ea6c70a35243a4c83cfceb6d9f2ce7) returns "ThunderKit"

## Remarks

Use this as a common root for staging Manifest content
