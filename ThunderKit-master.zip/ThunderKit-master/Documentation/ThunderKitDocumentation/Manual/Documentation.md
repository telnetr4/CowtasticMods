---
{ 
	"title" : "Documentation",
	"headerClasses" : [ "bm4", "page-header-container" ],
	"titleClasses" : [ "page-header" ],
	"iconClasses" : [ "header-icon", "TK_Documentation_2X_Icon" ]
}

---

ThunderKit's Documentation system is a simple, extensible, Markdown based
documentation solution that is organized with standard folders.
